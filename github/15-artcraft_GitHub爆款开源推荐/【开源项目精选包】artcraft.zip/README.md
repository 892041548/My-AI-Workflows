# storytold/artcraft · 极速上手实操说明

> **项目简介**：ArtCraft is an intentional crafting engine for artists, designers, and filmmakers
> **开源地址**：https://github.com/storytold/artcraft

---

## 🚀 极速上手 3 步走

### 1️⃣ 下载安装包或克隆源码
普通用户直接前往 GitHub Releases 或官网下载 dmg/exe 安装包；开发者可克隆仓库。

```bash
git clone https://github.com/storytold/artcraft.git && cd artcraft
```

### 2️⃣ 桌面端环境初始化与配置
开发者运行官方提供的 setup 脚本配置本地构建依赖与环境。

```bash
./script/artcraft setup
```

### 3️⃣ 启动应用并绑定模型
开发者直接通过脚本启动桌面端，或直接双击安装包，随后在设置中配置所需模型 API 即可开始创作。

```bash
./script/artcraft run
```

## 📋 前置环境要求
- 操作系统：Windows 10/11、macOS (Apple Silicon / Intel) 或 Linux
- 源码构建需配备：Rust 1.75+ 环境、CMake 及对应系统编译套件

## 💡 避坑指南
- Linux 用户需提前安装 libasound2-dev、libudev-dev 等系统依赖库后方可正常编译。
- 涉及 3D 高斯泼溅 (Gaussian Splats) 和实时网格渲染时，建议开启独立显卡硬件加速以防掉帧。

⭐ 觉得实用别忘了前往 GitHub 为原作者点亮 Star！