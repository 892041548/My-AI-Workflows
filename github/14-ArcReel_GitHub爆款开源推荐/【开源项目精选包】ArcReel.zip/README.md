# ArcReel/ArcReel · 极速上手实操说明

> **项目简介**：AI Agent 驱动的开源可自部署视频工作台：将小说与剧本转为角色、场景、道具资产、分镜、视频和剪映草稿，支持跨镜头一致性、多供应商与费用追踪 | Self-hosted AI video workspace for stories, storyboards and short-form video production
> **开源地址**：https://github.com/ArcReel/ArcReel

---

## 🚀 极速上手 3 步走

### 1️⃣ 拉取代码与配置环境
克隆官方仓库，进入 deploy 部署目录，复制一份标准环境配置文件：

```bash
git clone https://github.com/ArcReel/ArcReel.git && cd ArcReel/deploy && cp .env.example .env
```

### 2️⃣ 后台启动 Docker 容器
一键拉起工作台所有容器服务，密码留空时首次启动会自动生成并在控制台回写：

```bash
docker compose up -d
```

### 3️⃣ 登录工作台配置模型
浏览器访问 http://localhost:1241，使用默认账号 admin 登录，在设置页填入文本、图像与视频供应商 API Key 即可。

## 📋 前置环境要求
- Linux / macOS / Windows 环境并安装 Docker 及 Docker Compose
- 至少具备主流大模型与文生图/生视频 API 密钥（如 OpenAI 协议、MiniMax、Midjourney 兼容 API 等）

## 💡 避坑指南
- 默认暴露 1241 端口，严禁无鉴权直接暴露至公网，远程生产环境务必配置反向代理与 HTTPS。
- 草稿导出功能目前专为中国大陆版剪映深度适配，海外版 CapCut 兼容性尚未完全测试。

⭐ 觉得实用别忘了前往 GitHub 为原作者点亮 Star！