#!/usr/bin/env bash
echo "=========================================================="
echo "⚡ REA (Reverse Engineer Anything) 环境检测与一键初始化"
echo "=========================================================="

if command -v node >/dev/null 2>&1; then
    NODE_VERSION=$(node -v)
    echo "✔ 检测到 Node.js 版本: $NODE_VERSION"
    MAJOR_VER=$(echo $NODE_VERSION | sed "s/v//" | cut -d. -f1)
    if [ "$MAJOR_VER" -lt 22 ]; then
        echo "⚠️ 注意: REA 要求 Node.js 22.19+，当前版本可能过低。建议使用 nvm 切换或升级。"
    fi
else
    echo "❌ 未检测到 Node.js，请先前往 https://nodejs.org/ 安装最新 LTS 版本！"
    exit 1
fi

echo ""
echo "🚀 正在启动 REA Agent 初始化向导 (npx rea-agents setup)..."
npx rea-agents setup
