# manaflow-ai/cmux · 极速上手实操说明

> **项目简介**：Open source Ghostty-based macOS terminal with vertical tabs and notifications for AI coding agents. Built for multitasking, organization, and programmability.
> **开源地址**：https://github.com/manaflow-ai/cmux

---

## 🚀 极速上手 3 步走

### 1️⃣ 获取最新构建 Releases 包
前往官方 Releases 页面（https://github.com/manaflow-ai/cmux/releases）下载最新预编译安装包或二进制。

### 2️⃣ 系统安装与权限配置
根据平台系统进行签名、安装或必要权限授权。

### 3️⃣ 启动运行并载入配置
打开应用或通过命令行运行，完成初次初始化。

## 📋 前置环境要求
- 系统对应支持 (iOS / macOS / Windows / Linux)
- 支持的硬件芯片架构

## 💡 避坑指南
- 若为 iOS 侧载应用，个人免费 Apple ID 签名 7 天有效，需定期续签
- 如需特殊权限（如 JIT/无障碍），按官方引导工具配对启用

⭐ 觉得实用别忘了前往 GitHub 为原作者点亮 Star！